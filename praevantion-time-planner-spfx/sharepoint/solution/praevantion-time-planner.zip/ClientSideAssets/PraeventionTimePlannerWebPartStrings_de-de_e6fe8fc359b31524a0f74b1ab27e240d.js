define([], function() {
  return {
    "PropertyPaneDescription": "Konfiguration des Prävention Terminplaners",
    "BasicGroupName": "Grundeinstellungen",
    "DescriptionFieldLabel": "Beschreibung"
  }
});
