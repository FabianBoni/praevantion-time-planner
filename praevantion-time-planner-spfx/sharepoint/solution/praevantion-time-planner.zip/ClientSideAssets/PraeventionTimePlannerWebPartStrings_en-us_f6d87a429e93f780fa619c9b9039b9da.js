define([], function() {
  return {
    "PropertyPaneDescription": "Configuration of the Prevention Time Planner",
    "BasicGroupName": "Basic Settings",
    "DescriptionFieldLabel": "Description"
  }
});
